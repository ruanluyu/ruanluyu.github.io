# 世界の基盤CMD
---

**Lua (CPU & GPU)**モードで```cmd("Your code")```関数を用いて、cmdコマンドを実行します。


![LuaMode](LuaMode.png)


```lua:executeCMD.lua
version3()
cmd("echo Hello PixelsWorld! & pause");
```
