#　世界の郊外、JavaScript
---

**Lua (CPU & GPU)**モードで```js("Your code")```関数を用いて、JavaScriptを実行します。


![LuaMode](LuaMode.png)


```lua:executeJS.lua
version3()
js("alert('Hello PixelsWorld!')");
```

> 注意：PixelsWorldでJavaScriptの実行をAeのストラクチャよりお勧めしません。