#CMD Code
---
CMD commands can be executed by function ```cmd("Your cmd commands")``` on **Lua (CPU & GPU)** language mode. 



![LuaMode](LuaMode.png)


```lua:executeCMD.lua
version3()
cmd("echo Hello PixelsWorld! & pause");
```
