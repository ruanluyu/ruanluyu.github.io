# CMD Code
---
In **Lua (CPU & GPU)** mode, the pixel world can execute CMD commands using ```cmd("Your cmd commands")```.



![LuaMode](LuaMode.png)


```lua:executeCMD.lua
version3()
cmd("echo Hello PixelsWorld! & pause");
```