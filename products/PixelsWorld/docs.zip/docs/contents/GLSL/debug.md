#Debug
---
Check the debug checkbox in the plugin panel. 

If your program contains errors, it will be printed into left top corner of your screen when this is checked. 

<br>
