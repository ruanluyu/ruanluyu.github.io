# Debug
---
Check the debug checkbox in the plugin panel.

When there are error messages, they will be printed on the screen in red font.