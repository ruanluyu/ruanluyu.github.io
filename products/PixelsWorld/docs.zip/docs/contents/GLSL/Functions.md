# Functions
---
This section briefly introduces the built-in functions. These functions can be used **without any declaration**.