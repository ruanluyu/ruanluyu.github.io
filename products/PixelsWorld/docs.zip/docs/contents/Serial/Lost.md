# Help, I forgot to unregister!
------

## Solution

Solution: **Register on the new machine**

>The serial number authentication system will automatically delete seats that have not been active for more than a month in the cloud.

If you received the error message: `key_already_used`.  
This indicates that your previous seat hasn't been inactive long enough to be automatically deleted. Please wait up to a month before trying again.