# Help, I forgot to deactivate it!!!
------

## Solution

Soution: **Just input your serial number on your new machine. **

>The serial number authentication system will automatically delete seats that have not been active for more than one month in the cloud.

If you get a `key_already_used` error, This proves that your last seat hasn't been automatically deleted, please wait up to one month and try again.
