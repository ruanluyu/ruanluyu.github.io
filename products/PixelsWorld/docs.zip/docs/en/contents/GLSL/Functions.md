#Functions
---
This section will give a brief introduction of the functions created by us. 
The functions mentioned in this section could be immediately used **without any declaration**. 