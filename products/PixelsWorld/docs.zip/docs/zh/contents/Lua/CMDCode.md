#CMD代码
---
在 **Lua (CPU & GPU)** 模式下，像素世界可以通过 ```cmd("Your cmd commands")``` 执行CMD命令。



![LuaMode](LuaMode.png)


```lua:executeCMD.lua
version3()
cmd("echo Hello PixelsWorld! & pause");
```
