# Summary

## 1. 你好，像素世界！
* [成为创世神](README.md)
* [获得与使用](contents/HowTo.md)
* [前往论坛](contents/gotoForum.md)

## 2. 面板说明
* [世界法则编辑器](contents/Editor/ScriptWindow.md)
* [参数编辑器](contents/Editor/ParameterWindow.md)
* [预设管理](contents/Editor/SavePresets.md)

## 3. 代码说明
* [世界的中心Lua](contents/Lua/LuaCode.md)
    * [运行Lua](contents/Lua/RunLua.md)
    * [最重要的函数](contents/Lua/importantFuncs.md)
    * [链接参数](contents/Lua/LinkParameters.md)
    * [全局参数](contents/Lua/globals.md)
    * [函数列表](contents/Lua/FuncList.md)
    * [在Lua中运行GLSL ](contents/Lua/RunGLSL.md)
* [显卡狂战士GLSL](contents/GLSL/GLSLCode.md)
    * [快速开始](contents/GLSL/GetStart.md)
    * [运行GLSL](contents/GLSL/RunGLSL.md)
    * [函数](contents/GLSL/Functions.md)
        * [getColor](contents/GLSL/getColor.md)
        * [uv2xy,xy2uv](contents/GLSL/uvxy.md)
    * [链接参数](contents/GLSL/LinkParameters.md)
    * [调试](contents/GLSL/debug.md)
    * [高级设置](contents/GLSL/Advanced_settings.md)
    * [预定义](contents/GLSL/predefined.md)
* [模板圣域shadertoy](contents/GLSL/shadertoy.md)
* [世界的郊区JavaScript](contents/Lua/JavaScript.md)
* [世界的基盘CMD指令](contents/Lua/CMDCode.md)

## 4. 序列号注意事项
* [序列号使用约定](contents/Serial/SerialAttention.md)