#获得与使用
---
##下载

- 购买/下载[PixelsWorld](https://milai.tech/products/PixelsWorld/)

> ###请注意：
> 部分测试预设在非商业许可证下，使用前请留意源码中的许可证书。

- 把“MiLai”文件夹放在 :
> `AE安装目录/Support Files/Plug-ins/`

- 插件位于 :
> `AE安装目录/Support Files/Plug-ins/MiLai/PixelsWorld.aex`

##如何使用

- 打开 **Adobe After Effects**. 
-  **"Ctrl + N"**(或 **"Command + N"**) 新建合成。
- 新建一个纯色层
- 选择刚添加的图层
- **右键** => **效果** => **MiLai** => **PixelsWrold**
- 单击**"Edit"** 来改变 **"世界规则"**。
- 此时会**弹出菜单** 。
- 在右上处的**"Preset list"**选择 **"shadertoy"**
- 选择你喜欢的效果
- 单击 **"Ok"**.