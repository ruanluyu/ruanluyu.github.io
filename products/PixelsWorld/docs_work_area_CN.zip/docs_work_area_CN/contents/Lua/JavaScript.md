#JavaScript代码
---
在 **Lua (CPU & GPU)** 模式下，像素世界可以通过 ```pw.js``` 执行JavaScript代码。


![LuaMode](LuaMode.png)


```lua:executeJS.lua
pw.js("alert('Hello PixelsWorld!')");
```
