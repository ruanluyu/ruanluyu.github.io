#pw.lua(luaCode)
---

**说明：**

- 运行lua代码。

**参数：**

- pw.lua(luaCode). 
- luaCode：字符串。

**返回：**

- 无

**示例**
```lua:lua.lua
pw.lua("pw.report(\"123+456 = \"..(123+456))")
```

