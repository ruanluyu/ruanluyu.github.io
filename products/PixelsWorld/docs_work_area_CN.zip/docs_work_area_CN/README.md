#成为创世神
---

 <img src="../PixelsWorld_LOGO.png" width = "500px" height = "500px" alt="PixelsWorld_LOGO"/>

> PixelsWorld 文档版本 : **v3.0.0**<br>
> 作者：[中梓星音](https://space.bilibili.com/564908)<br>
> 协助：[月离](https://space.bilibili.com/4279370)<br>
> 历史版本<br>
> [v2.3.1](https://milai.tech/products/PixelsWorld/old_docs/v2_3_1/docs_CN/index.html)<br>
> [v2.0](https://milai.tech/products/PixelsWorld/old_docs/v2_0/docs_CN/index.html)<br>
> [v1.0](https://milai.tech/products/PixelsWorld/old_docs/v1_0/docs_CN/index.html)<br>
> [English version](https://milai.tech/products/PixelsWorld/docs/)


<span style="color:rgb(255,0,0);">注意，文档3.0.0仍在施工中！请前往上面的v2.3.1文档！</span>

## 欢迎进入像素世界！
我们把像素世界中最精华的部分都压缩在这一页的内容里。若掌握了本页内容，您就会成为像素世界新的创世神！

## 简单来说
**像素世界是一款通过代码来渲染图像的插件**
- 您可以直接使用其他艺术家写好特效渲染场景。
- 您可以通过学习简单的绘图代码，用像素世界程序化绘制图形。
- 您可以通过学习硬核的GLSL代码，用像素世界写特效。

## 在像素世界中写代码是什么感觉？
简单来说，像素世界就是一个绘画机器人，您把需要绘制的图案、绘制的地点按照绘制顺序告诉它，它会依次帮您绘制场景。

例如您想在屏幕正中间绘制一个小房子，而拿着画笔的是您的好朋友（并且TA不知道您想要绘制的场景），思考一下您应该如何和TA一起完成这幅作品。

通常，您可能会这么说：

```cmd:DrawHouse.myBro
在画布中间绘制一个房子
```

当然这么说是ok的，但是如果加上“*我们只能告诉TA画的位置和基本图形及颜色，不能直接告诉TA答案*”这样的限制的话，我们大概需要这么说：

```cmd:DrawHouse2.myBro
把画笔移到正中间
给画笔沾上黄色涂料
以画笔为中心绘制一个10cm的正方形
把画笔向上移动5cm
给画笔沾上红色颜料
绘制一个底边15cm，高10cm的等腰三角形
```

至此，您就和您的朋友完成了一副房子的水彩大作！

其实上面您发出的指令正是要填入PixelsWorld中的代码，把它整理一下大概需要写成下面的形式：

```lua:DrawHouse3.lua
version3() -- 使用版本3（每次绘制开始必须加的代码）
move(width/2, height/2) -- 画笔移至中央
rotateX(PI) -- 朝上
fill(1,1,0) -- 黄色涂料（Red=1,Green=1,Blue=0）
rect(100) -- 100像素尺寸的正方形
fill(1,0,0) -- 红色颜料（Red=1,Green=0,Blue=0）
move(0,50) -- 向上移动
tri(150,100) -- 绘制150底100高的等腰三角形
```

> 这里有一个技术细节是，我们在指令中没有提到`rotateX(PI)`，因为Ae中坐标默认是朝下是Y轴正方向，我们需要沿着X轴把Y轴转180度，如果去掉这一行，move(0,50)将会把画笔向下移动50像素单位。

## 开天辟地，制作您的第一幅作品
为了使用像素世界，首先需要把它放到一个固态层上。
确保语言(Language)选项切换到Lua模式后，点击Edit按钮。（如下图所示）点击Ok按钮后，就能看到由您指导绘制的小房子了。

![演示](contents/PutPW_GetStart.png)

![结果](contents/HouseRes.png)

当然，只是这样的话未免有些无聊，我们需要给这个小房子加入一些可控性。比如，我们首先就想把这辣眼的配色给改掉。

这里我们想让颜色控制器来修改房子的配色，我们需要做如下修改：

```lua:DrawHouse4.lua
version3() -- 使用版本3（每次绘制开始必须加的代码）
move(width/2, height/2) -- 画笔移至中央
rotateX(PI) -- 朝上
fill(color(0)) -- 涂上0号颜色
rect(100) -- 100像素尺寸的正方形
fill(color(1)) -- 涂上1号颜色
move(0,50) -- 向上移动
tri(150,100) -- 绘制150底100高的等腰三角形
```

当你点击Ok的时候，会发现场景中的房子消失了！

其实房子没消失，只是因为我们的颜色控制器都是黑色的。
打开Colors列表，找到前两个控制器，调成你想要的颜色即可。
![控制结果](contents/ColorHouse.png)

## 村长就是我！创建更多的房子

使用代码的一个甜头就是可以做重复性极高的动作。

我们使用的代码语言（Lua）中，有重复一段代码的功能。

```lua:RepeatHouse.lua
version3() -- 使用版本3（每次绘制开始必须加的代码）
move(width/2, height/2) -- 画笔移至中央
rotateX(PI) -- 朝上
for i=1,3 do -- 重复段开始标志（共重复3次）
fill(color(0)) -- 涂上0号颜色
rect(100) -- 100像素尺寸的正方形
fill(color(1)) -- 涂上1号颜色
move(0,50) -- 向上移动50单位
tri(150,100) -- 绘制150底100高的等腰三角形
move(0,-50) -- 向下移动回50单位
move(175,0) -- 画笔朝右移动175单位
end -- 重复段结束标志
```

![重复结果](contents/RepeatHouse.png)

最后我们想让颜色控制器附上自己的名字，方便我们之后使用，我们可以在参数编辑器里修改参数名称：

![设置名称](contents/SetColorsName.png)

![设置结果](contents/ParamRes.png)


## 保存指令，回收利用

> 注意，这一步需要Ae开启管理员模式，请确保以管理员模式打开Ae。

首先，先新建一个自己的预设栏目：

![新建栏目](contents/AddColumn.png)

然后在自己的预设栏目下，保存自己的预设：

![保存预设](contents/SavePreset.png)

### 使用预设

选中您想要的预设，点击右面的Replace按钮即可。


## 恭喜您！

您已经掌握了像素世界的大体使用流程！



<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>