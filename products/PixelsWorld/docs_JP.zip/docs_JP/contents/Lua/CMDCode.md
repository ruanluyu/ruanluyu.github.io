# CMDコード
---
**Lua (CPU & GPU)** モードで、ピクセルワールドは```cmd("Your cmd commands")```を使用してCMDコマンドを実行できます。

![LuaMode](LuaMode.png)

```lua:executeCMD.lua
version3()
cmd("echo Hello PixelsWorld! & pause");
```