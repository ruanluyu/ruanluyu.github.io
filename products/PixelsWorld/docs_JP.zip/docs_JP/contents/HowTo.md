# 入手とダウンロード
---
## 入手方法

- [購入ページ/ダウンロードページ](https://milai.tech/products/PixelsWorld/)

- 「MiLai」フォルダーを次のパスにおいてください：
> `AEルートフォルダー/Support Files/Plug-ins/`

- プラグインは次のパスにあるかどうかを確認してください：
> `AEルートフォルダー/Support Files/Plug-ins/MiLai/PixelsWorld.aex`

## 適用方法

- **Adobe After Effects**を開きます. 
- **"Ctrl + N"**　でコンポジションを新規します。
- 平面レイヤーを新規します。
- 新規したレイヤーを選択肢ます。
- **右クリック** => **エフェクト** => **MiLai** => **PixelsWrold**
- **"Edit"** をクリックし **"世界ルール"** を変えます。
- ここでパネルが出てきます。
- **"Preset list"**　でお気に入りのコラムを選択肢て下のリストから一つのプリセットを選択してください。
- "Replace"をクリックしてください。
- **"Ok"**　をクリックしてください。