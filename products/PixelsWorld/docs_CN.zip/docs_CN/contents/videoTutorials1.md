第一期 基础操作（全6集）
-----
<div class="center">
<iframe src="//player.bilibili.com/player.html?aid=800389613&bvid=BV13y4y1q7MC&cid=259040682&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width=800 height=500> </iframe>
<iframe src="//player.bilibili.com/player.html?aid=800389613&bvid=BV13y4y1q7MC&cid=259040682&page=2" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width=800 height=500> </iframe>
<iframe src="//player.bilibili.com/player.html?aid=800389613&bvid=BV13y4y1q7MC&cid=259040682&page=3" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width=800 height=500> </iframe>
<iframe src="//player.bilibili.com/player.html?aid=800389613&bvid=BV13y4y1q7MC&cid=259040682&page=4" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width=800 height=500> </iframe>
<iframe src="//player.bilibili.com/player.html?aid=800389613&bvid=BV13y4y1q7MC&cid=259040682&page=5" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width=800 height=500> </iframe>
<iframe src="//player.bilibili.com/player.html?aid=800389613&bvid=BV13y4y1q7MC&cid=259040682&page=6" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width=800 height=500> </iframe>
</div>